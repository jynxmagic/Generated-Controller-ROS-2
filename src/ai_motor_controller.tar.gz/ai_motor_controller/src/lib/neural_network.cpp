#include <Eigen/Dense>
#include <ai_motor_controller/neural_network.h>

namespace ai_motor_controller
{

    NeuralNetwork::NeuralNetwork() {}

    Eigen::MatrixXf NeuralNetwork::forward_propagate(Eigen::MatrixXf input)
    {
        Eigen::MatrixXf output0 = (NeuralNetwork::policy_network_w0 * input + NeuralNetwork::policy_network_b0).cwiseMax(0);
        Eigen::MatrixXf output1 = (NeuralNetwork::policy_network_w1 * output0 + NeuralNetwork::policy_network_b1).cwiseMax(0);
        Eigen::MatrixXf output2 = (NeuralNetwork::policy_network_w2 * output1 + NeuralNetwork::policy_network_b2);
        return output2.unaryExpr([](float x)
                                 { return std::tanh(x); }); // tanh activation function
    }

    // Eigen::Matrix<double, 4, 1> policy_network_b3{{0.052487258f}, {0.007309009f}, {0.06450168f}, {-0.005422031f}};
} // namespace ai_motor_controller