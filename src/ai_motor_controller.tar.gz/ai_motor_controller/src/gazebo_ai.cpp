#include <px4_msgs/msg/offboard_control_mode.hpp>
#include <px4_msgs/msg/trajectory_setpoint.hpp>
#include <px4_msgs/msg/vehicle_rates_setpoint.hpp>
#include <px4_msgs/msg/vehicle_angular_velocity.hpp>
#include <px4_msgs/msg/vehicle_command.hpp>
#include <px4_msgs/msg/vehicle_control_mode.hpp>
#include <px4_msgs/msg/vehicle_local_position.hpp>
#include <px4_msgs/msg/vehicle_attitude.hpp>
#include <px4_msgs/msg/hover_thrust_estimate.hpp>
#include <rclcpp/rclcpp.hpp>
#include <stdint.h>
#include <chrono>
#include <iostream>
#include <fstream>
#include <cmath>
#include <ai_motor_controller/neural_network.h>
#include <px4_ros_com/frame_transforms.h>

using namespace std::chrono;
using namespace std::chrono_literals;
using namespace px4_msgs::msg;

class PID
{
public:
    PID(float kp, float ki, float kd)
        : kp_(kp), ki_(ki), kd_(kd), prev_error_(0.0), integral_(0.0) {}

    float update(float setpoint, float measured, float dt)
    {
        float error = setpoint - measured;
        integral_ += error * dt;
        float derivative = (error - prev_error_) / dt;
        prev_error_ = error;
        return kp_ * error + ki_ * integral_ + kd_ * derivative;
    }

private:
    float kp_, ki_, kd_;
    float prev_error_, integral_;
};

class OffboardControl : public rclcpp::Node
{
public:
    OffboardControl() : Node("offboard_control"), pid_roll_(0.25f, 0.05, 0.05), pid_pitch_(0.25f, 0.05, 0.05), pid_yaw_(0.0, 0.0, 0.00), pid_thrust_(0.3f, 0.05, 0.01)
    {

        // pubs
        offboard_control_mode_publisher_ = this->create_publisher<OffboardControlMode>("/fmu/in/offboard_control_mode", 10);
        rates_setpoint_publisher_ = this->create_publisher<VehicleRatesSetpoint>("/fmu/in/vehicle_rates_setpoint", 10);
        vehicle_command_publisher_ = this->create_publisher<VehicleCommand>("/fmu/in/vehicle_command", 10);
        trajectory_setpoint_publisher_ = this->create_publisher<TrajectorySetpoint>("/fmu/in/trajectory_setpoint", 10);

        // subs
        rmw_qos_profile_t qos_profile = rmw_qos_profile_sensor_data;
        auto qos = rclcpp::QoS(rclcpp::QoSInitialization(qos_profile.history, 5), qos_profile);
        local_position_subscriber_ = this->create_subscription<VehicleLocalPosition>(
            "/fmu/out/vehicle_local_position", qos, [this](VehicleLocalPosition::UniquePtr msg)
            {
                local_position_x_ = msg->y;
                local_position_y_ = msg->x;
                local_position_z_ = -msg->z;
                local_velocity_x_ = msg->vy;
                local_velocity_y_ = msg->vx;
                local_velocity_z_ = -msg->vz; });

        ang_vel_subscriber_ = this->create_subscription<VehicleAngularVelocity>(
            "/fmu/out/vehicle_angular_velocity", qos, [this](VehicleAngularVelocity::UniquePtr msg)
            {
                current_roll_rate_ = msg->xyz[2];
                current_pitch_rate_ = msg->xyz[1];
                current_yaw_rate_ = msg->xyz[0]; });
        attitude_subscriber_ = this->create_subscription<VehicleAttitude>(
            "/fmu/out/vehicle_attitude", qos, [this](VehicleAttitude::UniquePtr msg)
            {
                Eigen::Quaterniond q(msg->q[0], msg->q[1], msg->q[2], msg->q[3]);
                Eigen::Vector3d euler_enu = px4_ros_com::frame_transforms::utils::quaternion::quaternion_to_euler(px4_ros_com::frame_transforms::ned_to_enu_orientation(q));

                roll = static_cast<float>(euler_enu[0]);
                pitch = static_cast<float>(euler_enu[1]);
                yaw = static_cast<float>(euler_enu[2]); });

        hte_subscriber_ = this->create_subscription<HoverThrustEstimate>(
            "/fmu/out/hover_thrust_estimate", qos, [this](HoverThrustEstimate::UniquePtr msg)
            { hte = msg->hover_thrust; });

        // log file
        traj_log_.open("traj.csv");
        traj_log_ << "time,x,y,z,type" << std::endl;
        // Runner
        auto timer_callback = [this]() -> void
        {
            if (offboard_setpoint_counter_ == 10)
            {
                // Change to Offboard mode after 10 setpoints
                this->publish_vehicle_command(VehicleCommand::VEHICLE_CMD_DO_SET_MODE, 1, 6);

                // Arm the vehicle
                this->arm();
            }

            update_trajectory();

            // // offboard_control_mode needs to be paired with trajectory_setpoint
            publish_offboard_control_mode();
            // publish_rates_setpoint();

            // stop the counter after reaching 11
            if (offboard_setpoint_counter_ < 11)
            {
                offboard_setpoint_counter_++;
            }
        };
        generateWaypoints();
        start_time_ = std::chrono::steady_clock::now();
        timer_ = this->create_wall_timer(8ms, timer_callback);
    }

    ~OffboardControl() // Destructor
    {
        if (traj_log_.is_open())
            traj_log_.close();
    }

    void arm();
    void disarm();

private:
    rclcpp::TimerBase::SharedPtr timer_;
    ai_motor_controller::NeuralNetwork nn;
    // Publishers
    rclcpp::Publisher<OffboardControlMode>::SharedPtr offboard_control_mode_publisher_;
    rclcpp::Publisher<VehicleRatesSetpoint>::SharedPtr rates_setpoint_publisher_;
    rclcpp::Publisher<VehicleCommand>::SharedPtr vehicle_command_publisher_;
    rclcpp::Publisher<TrajectorySetpoint>::SharedPtr trajectory_setpoint_publisher_;

    // Subscribers
    rclcpp::Subscription<VehicleLocalPosition>::SharedPtr local_position_subscriber_;
    rclcpp::Subscription<VehicleAngularVelocity>::SharedPtr ang_vel_subscriber_;
    rclcpp::Subscription<VehicleAttitude>::SharedPtr attitude_subscriber_;
    rclcpp::Subscription<HoverThrustEstimate>::SharedPtr hte_subscriber_;

    // Trajectory tracking (Hungarian programming notation, x_ means class member variable)
    float d_roll_, d_pitch_, d_yaw_, d_thrust_;
    const float t_z_ = 1.5f;
    PID pid_roll_;
    PID pid_pitch_;
    PID pid_yaw_;
    PID pid_thrust_;
    std::ofstream traj_log_;

    std::chrono::steady_clock::time_point start_time_;
    bool ascended_;
    float waypoints_[64][3];
    float velocity_[64][3];
    int current_waypoint_ = 0;
    // Quad state
    float local_position_x_;
    float local_position_y_;
    float local_position_z_;
    float local_velocity_x_;
    float local_velocity_y_;
    float local_velocity_z_;
    float roll;
    float pitch;
    float yaw;
    float current_roll_rate_;
    float current_pitch_rate_;
    float current_yaw_rate_;
    float a0;
    float a1;
    float a2;
    float a3;
    float hte;
    bool body_rate_enabled_ = true;

    std::atomic<uint64_t> timestamp_; //!< common synced timestamped

    uint64_t offboard_setpoint_counter_ = 0; //!< counter for the number of setpoints sent

    void publish_offboard_control_mode();
    void publish_rates_setpoint();
    void update_trajectory();
    void generateWaypoints();
    void publish_vehicle_command(uint16_t command, float param1 = 0.0, float param2 = 0.0);
};

/**
 * @brief Send a command to Arm the vehicle
 */
void OffboardControl::arm()
{
    publish_vehicle_command(VehicleCommand::VEHICLE_CMD_COMPONENT_ARM_DISARM, 1.0);

    RCLCPP_INFO(this->get_logger(), "Arm command send");
}

/**
 * @brief Send a command to Disarm the vehicle
 */
void OffboardControl::disarm()
{
    publish_vehicle_command(VehicleCommand::VEHICLE_CMD_COMPONENT_ARM_DISARM, 0.0);

    RCLCPP_INFO(this->get_logger(), "Disarm command send");
}

void OffboardControl::generateWaypoints()
{
    float start_x = 0.0;
    float start_y = 0.0;
    float current_z = t_z_;

    double max_radius = 1.0;
    int points = 64;
    float angle_increment = 2.0 * M_PI / points;

    // NED fo8
    for (int point = 0; point < points; ++point)
    {
        double angle = angle_increment * point;

        // lx + ly
        double x = start_x + max_radius * sin(angle);
        double y = start_y + max_radius * sin(2 * angle);
        traj_log_ << "0.0" << "," << x << "," << y << "," << t_z_ << "," << "desired" << std::endl;
        waypoints_[point][0] = x;
        waypoints_[point][1] = y;
        waypoints_[point][2] = t_z_;
    }
    for (int point = 0; point < points; ++point)
    {
        // lvx + lvy
        int next_point = (point + 1) % points;
        double dx = waypoints_[next_point][0] - waypoints_[point][0];
        double dy = waypoints_[next_point][1] - waypoints_[point][1];
        velocity_[point][0] = dx;
        velocity_[point][1] = dy;
        velocity_[point][2] = 0.0f;
    }
}

void OffboardControl::update_trajectory()
{
    float time = std::chrono::duration<float>(std::chrono::steady_clock::now() - start_time_).count();
    // ascend
    if (!ascended_)
    {
        // Lift off phase to reach target altitude
        d_roll_ = 0.0;
        d_pitch_ = 0.0;
        d_yaw_ = 0.0;
        // d_thrust_ = 0.6 * 9.81; // Assuming measured in N
        std::cout << "Not ascended yet" << std::endl;
        px4_msgs::msg::TrajectorySetpoint setpoint;
        setpoint.timestamp = this->get_clock()->now().nanoseconds() / 1000;
        setpoint.position = {0.0, 0.0, -t_z_ - 0.1f};
        setpoint.velocity = {NAN, NAN, NAN};
        setpoint.acceleration = {NAN, NAN, NAN};
        setpoint.jerk = {NAN, NAN, NAN};
        setpoint.yaw = NAN;
        setpoint.yawspeed = NAN;
        trajectory_setpoint_publisher_->publish(setpoint);
        if (std::abs(local_position_z_) > t_z_)
        {
            std::cout << "Ascended" << std::endl;
            ascended_ = true;
        }
    }
    else
    {
        // Trajectory tracking
        // Get the current waypoint
        if (current_waypoint_ == 64)
        {
            current_waypoint_ = 0;
        }
        float x = waypoints_[current_waypoint_][0];
        float y = waypoints_[current_waypoint_][1];
        float z = waypoints_[current_waypoint_][2];
        if (std::fabs(local_position_x_ - x) < 0.3 && std::fabs(local_position_y_ - y) < 0.3) // NED -> ENU
        {
            std::cout << "new waypoint" << std::endl;
            current_waypoint_++;
        }

        float dx = x - local_position_x_;
        float dy = y - local_position_y_;
        float dz = z - local_position_z_;

        Eigen::Vector<float, 16> input{dx, dy, dz, local_velocity_x_, local_velocity_y_, local_velocity_z_, roll, pitch, yaw, current_roll_rate_, current_pitch_rate_, current_yaw_rate_, a0, a1, a2, a3};
        Eigen::MatrixXf output = nn.forward_propagate(input);
        a0 = output(0, 0); // collective thrust needs expressing as a function of hte (?)

        float remaining_thrust = 1 - hte;

        float collective_thrust = a0 < 0 ? a0 * hte : a0 * remaining_thrust + hte;

        a1 = output(1, 0);
        a2 = output(2, 0);
        a3 = output(3, 0);

        // convert enu body frame to ned body frame
        float roll_rate_cmd = a1 * 3.83972f;
        float pitch_rate_cmd = a2 * 3.83972f;
        float yaw_rate_cmd = a3 * 3.83972f;

        VehicleRatesSetpoint msg{};
        msg.roll = roll_rate_cmd;
        msg.pitch = pitch_rate_cmd;
        msg.yaw = yaw_rate_cmd;
        msg.thrust_body[0] = 0.0f;
        msg.thrust_body[1] = 0.0f;
        msg.thrust_body[2] = -collective_thrust; // negative thrust demand
        msg.reset_integral = false;
        msg.timestamp = this->get_clock()->now().nanoseconds() / 1000;
        rates_setpoint_publisher_->publish(msg);

        // trajectory setpoint publisher
        //  px4_msgs::msg::TrajectorySetpoint setpoint;
        //  setpoint.timestamp = this->get_clock()->now().nanoseconds() / 1000;
        //  setpoint.position = {x, y, -z};
        //  setpoint.velocity = {velocity_[current_waypoint_][0], velocity_[current_waypoint_][1], 0.0f};
        //  setpoint.acceleration = {NAN, NAN, NAN};
        //  setpoint.jerk = {NAN, NAN, NAN};
        //  setpoint.yaw = NAN;
        //  setpoint.yawspeed = NAN;
        //  trajectory_setpoint_publisher_->publish(setpoint);
        // std::cout << "trajectory setpoint sent" << std::endl;
    }
    // // fo8 {body rate tracking}
    // publish_rates_setpoint()
    traj_log_ << time << "," << local_position_x_ << "," << local_position_y_ << "," << local_position_z_ << "," << "true" << std::endl;
}
/**
 * @brief Publish the offboard control mode.
 *        For this example, only position and altitude controls are active.
 */
void OffboardControl::publish_offboard_control_mode()
{
    OffboardControlMode msg{};
    msg.position = true;
    msg.velocity = false;
    msg.acceleration = false;
    msg.attitude = false;
    msg.body_rate = body_rate_enabled_;
    msg.timestamp = this->get_clock()->now().nanoseconds() / 1000;
    offboard_control_mode_publisher_->publish(msg);
}

void OffboardControl::publish_rates_setpoint() // 10Hz
{
    // pid
    float roll_rate_cmd = pid_roll_.update(d_roll_, current_roll_rate_, 0.1);
    std::cout << "cur roll: " << current_roll_rate_ << std::endl;
    float pitch_rate_cmd = pid_pitch_.update(d_pitch_, current_pitch_rate_, 0.1);
    std::cout << "cur pitch: " << current_pitch_rate_ << std::endl;
    float yaw_rate_cmd = pid_yaw_.update(d_yaw_, current_yaw_rate_, 0.1);
    float thrust_cmd = pid_thrust_.update(t_z_, std::abs(local_position_z_), 0.1); // this is naughty, unbounded. maybe explode
    std::cout << "col thrust: " << thrust_cmd << std::endl;

    // msg
    VehicleRatesSetpoint msg{};
    msg.roll = roll_rate_cmd;
    msg.pitch = pitch_rate_cmd;
    msg.yaw = yaw_rate_cmd;
    msg.thrust_body[0] = 0.0f;
    msg.thrust_body[1] = 0.0f;
    msg.thrust_body[2] = -thrust_cmd; // negative thrust demand
    msg.reset_integral = false;
    msg.timestamp = this->get_clock()->now().nanoseconds() / 1000;
    rates_setpoint_publisher_->publish(msg);
}

/**
 * @brief Publish vehicle commands
 * @param command   Command code (matches VehicleCommand and MAVLink MAV_CMD codes)
 * @param param1    Command parameter 1
 * @param param2    Command parameter 2
 */
void OffboardControl::publish_vehicle_command(uint16_t command, float param1, float param2)
{
    VehicleCommand msg{};
    msg.param1 = param1;
    msg.param2 = param2;
    msg.command = command;
    msg.target_system = 1;
    msg.target_component = 1;
    msg.source_system = 1;
    msg.source_component = 1;
    msg.from_external = true;
    msg.timestamp = this->get_clock()->now().nanoseconds() / 1000;
    vehicle_command_publisher_->publish(msg);
}

int main(int argc, char *argv[])
{
    std::cout << "Starting offboard control node..." << std::endl;
    setvbuf(stdout, NULL, _IONBF, BUFSIZ);
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<OffboardControl>());

    rclcpp::shutdown();
    return 0;
}